<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="48x4x8" tilewidth="48" tileheight="48" tilecount="1" columns="1">
 <properties>
  <property name="collision" type="bool" value="true"/>
 </properties>
 <image source="../tile.png" width="48" height="48"/>
</tileset>
