package com.mygdx.pokemonrpgme;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class CharacterSelectScreen implements Screen {
    private OrthographicCamera camera;
    private FitViewport viewport;
    private Stage stage;
    private SpriteBatch batch;
    private GameLauncher game;
    private BitmapFont font;

    public CharacterSelectScreen(GameLauncher game) {
        this.game = game;
        camera = new OrthographicCamera();
        viewport = new FitViewport(915, 610, camera);
        stage = new Stage(viewport);
        batch = new SpriteBatch();

        // Load a BitmapFont
        font = new BitmapFont();
        font.getData().setScale(2f); // Scale the font to make it bigger

        // Create TextButtonStyle
        TextButton.TextButtonStyle buttonStyle = new TextButton.TextButtonStyle();
        buttonStyle.up = null; 
        buttonStyle.down = null; 
        buttonStyle.font = font;

        // Create character select button
        TextButton characterButton1 = new TextButton("Starborn", buttonStyle);
        TextButton characterButton2 = new TextButton("Kael", buttonStyle);
        TextButton characterButton3 = new TextButton("Lyra", buttonStyle);
        characterButton1.setPosition(viewport.getWorldWidth() / 2 - characterButton1.getWidth() / 2, 400);
        characterButton1.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new StoryScreen(game, new ImperialGuardFaction("Imperial Guards")));
            }
        });

        characterButton2.setPosition(viewport.getWorldWidth() / 2 - characterButton2.getWidth() / 2, 300);
        characterButton2.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new StoryScreen(game, new BloodyNecronsFaction("Bloody Necrons")));
            }
        });

        characterButton3.setPosition(viewport.getWorldWidth() / 2 - characterButton3.getWidth() / 2, 200);
        characterButton3.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new StoryScreen(game, new SpaceSoldiersFaction("Space Soldiers")));
            }
        });

        // Add button to the stage
        stage.addActor(characterButton1);
        stage.addActor(characterButton2);
        stage.addActor(characterButton3);
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        stage.dispose();
        batch.dispose();
        font.dispose();
    }
}
