package com.mygdx.pokemonrpgme;

import java.util.Random;

public class Enemy {
    private String name;
    private int health;
    private final Random random = new Random();

    public Enemy(String name, int health) {
        this.name = name;
        this.health = health;
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public boolean isAlive() {
        return health > 0;
    }

    public void takeDamage(int damage) {
        health -= damage;
        if (health < 0) {
            health = 0;
        }
    }

    public int makeAttack() {
        return random.nextInt(10) + 1; // Random damage between 1 and 10
    }
}
