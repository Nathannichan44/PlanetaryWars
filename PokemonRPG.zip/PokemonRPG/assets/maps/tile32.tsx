<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tile32" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <properties>
  <property name="walkable" type="bool" value="true"/>
 </properties>
 <image source="tiles32.png" width="32" height="32"/>
 <tile id="0">
  <properties>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
