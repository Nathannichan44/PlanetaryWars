package com.mygdx.pokemonrpgme;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.utils.viewport.FitViewport;

import java.util.List;

public class StoryScreen implements Screen {
    private OrthographicCamera camera;
    private FitViewport viewport;
    private Stage stage;
    private SpriteBatch batch;
    private GameLauncher game;
    private BitmapFont font;
    private Label storyLabel;
    private List<String> storytellingLines;
    private int currentLine = 0;

    public StoryScreen(GameLauncher game, Faction faction) {
        this.game = game;
        this.storytellingLines = faction.getStorytellingLines();
        camera = new OrthographicCamera();
        viewport = new FitViewport(915, 610, camera);
        stage = new Stage(viewport);
        batch = new SpriteBatch();

        // Load a BitmapFont
        font = new BitmapFont();
        font.getData().setScale(1.5f); // Scale the font to make it bigger

        // Create story label
        storyLabel = new Label(storytellingLines.get(currentLine), new Label.LabelStyle(font, null));
        storyLabel.setPosition(10, viewport.getWorldHeight() - 520);
        storyLabel.setWrap(true);
        storyLabel.setWidth(viewport.getWorldWidth() - 20);

        // Add label to the stage
        stage.addActor(storyLabel);
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.act(delta);
        stage.draw();

        // Check if the user clicked and there are more lines to display
        if (Gdx.input.justTouched() && currentLine < storytellingLines.size() - 1) {
            currentLine++;
            storyLabel.setText(storytellingLines.get(currentLine));
        } else if (Gdx.input.justTouched() && currentLine == storytellingLines.size() - 1) {
            game.setScreen(new GameScreen(game));
        }
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        stage.dispose();
        batch.dispose();
        font.dispose();
    }
}
