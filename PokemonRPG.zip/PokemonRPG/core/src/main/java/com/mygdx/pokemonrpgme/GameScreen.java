package com.mygdx.pokemonrpgme;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class GameScreen implements Screen {
    private TiledMap map;
    private OrthogonalTiledMapRenderer renderer;
    private OrthographicCamera camera;
    private PlayerIcon player;
    private SpriteBatch batch;
    private GameLauncher game;
    private Input input = Gdx.input;

    public GameScreen(GameLauncher game) {
        this.game = game;
    }

    @Override
    public void show() {
        map = new TmxMapLoader().load("maps/homes2.tmx");
        renderer = new OrthogonalTiledMapRenderer(map, 1.05f);


        TiledMapTileLayer collisionLayer = (TiledMapTileLayer) map.getLayers().get("Collision");
        player = new PlayerIcon(collisionLayer);

        batch = new SpriteBatch();

        // Initialize the camera
        camera = new OrthographicCamera();
        float mapWidth = map.getProperties().get("width", Integer.class) * PlayerIcon.TILE_SIZE;
        float mapHeight = map.getProperties().get("height", Integer.class) * PlayerIcon.TILE_SIZE;
        camera.setToOrtho(false, mapWidth, mapHeight);
        camera.update();
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Update the player
        player.update(delta);

        // Render the map
        renderer.setView(camera);
        renderer.render();

        // Render the player
        batch.begin();
        player.render(batch);
        batch.end();

        // Check for combat trigger
        if (input.isKeyPressed(Input.Keys.F)) { // Example coordinate for combat trigger
            initiateCombat();
        }
    }

    @Override
    public void dispose() {
        map.dispose();
        renderer.dispose();
        batch.dispose(); // Dispose of the batch when done.
    }

    @Override
    public void resize(int width, int height) {
        camera.viewportWidth = width;
        camera.viewportHeight = height;
        camera.update();
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    private void initiateCombat() {
        Player player = new Player("Imperial Guard", 10,10); // Example player
        Enemy enemy = new Enemy("Magmus", 50); // Example enemy
        game.setScreen(new CombatScreen(game, player, enemy));
    }
}
