package com.mygdx.pokemonrpgme;

import java.util.Random;

public class Player extends Character {
    private String name;
    private int health=1;
    private int maxHealth=1;
    private int damage=1;

    private final Random random = new Random();

    public Player(String name, int health, int damage) {
        super(name, health, damage);
        initialize(health, damage);
            };

            public void initialize(int health, int damage) {
                setDamage(damage);
                setHealth(health);
                this.maxHealth = health;
            }
            
            @Override
    public String getName() {
        return name;
    }

    @Override
    public int getHealth() {
        return health;
    }

    @Override
    public boolean isAlive() {
        return health > 0;
    }

    @Override
    public void takeDamage(int damage) {
        health -= damage;
        if (health < 0) {
            health = 0;
        }
    }

    @Override
    public void setHealth(int health) {
        this.health = health;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    @Override
    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int attack() {
        return random.nextInt(damage)+1;
    }

    @Override
    public void defend() {
    }
}
