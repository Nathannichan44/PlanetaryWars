package com.mygdx.pokemonrpgme;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.math.Vector2;
import java.util.Random;

public class PlayerIcon {
    public static final int TILE_SIZE = 16; 
    private static float SPEED = 2; // Movement speed
    private float x, y;
    private int direction = 0; // 0 = Down, 1 = Left, 2 = Right, 3 = Up
    private boolean isMoving = false;
    private float stateTime = 0f;
    private GameLauncher game;
    
    private Texture texture;
    private Animation<TextureRegion>[] walkAnimations;
    private TextureRegion idleFrame;

    private TiledMapTileLayer collisionLayer; // Add this
    private int troops;
    private int damage;
    private int maxTroops;

    private Random random = new Random();

    public PlayerIcon(TiledMapTileLayer collisionLayer) {
        this.collisionLayer = collisionLayer;  // Initialize collision layer
        texture = new Texture("spritesheet.png");
        walkAnimations = new Animation[4];
        
        TextureRegion[][] frames = TextureRegion.split(texture, TILE_SIZE, TILE_SIZE);
        
        for (int i = 0; i < 4; i++) {
            Array<TextureRegion> walkFrames = new Array<>();
            for (int j = 1; j < 4; j++) {
                walkFrames.add(frames[i][j]);
            }
            walkAnimations[i] = new Animation<>(0.1f, walkFrames, Animation.PlayMode.LOOP);
        }
        
        idleFrame = frames[0][0];
        x = 110;
        y = 110;
    }


    private boolean isTileWalkable(float x, float y) {
        int tileX = (int) (x / collisionLayer.getTileWidth());
        int tileY = (int) (y / collisionLayer.getTileHeight());
        
        TiledMapTileLayer.Cell cell = collisionLayer.getCell(tileX, tileY);
        if (cell != null) {
            Object walkable = cell.getTile().getProperties().get("walkable"); // Check custom property
            return walkable != null && (boolean) walkable; // Return true if walkable is true
        }
        return false; // Default to not walkable if no property is set
    }

    public void update(float delta) {
        isMoving = false;
    
        float newX = x;
        float newY = y;

        if (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) || Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT)){
            SPEED = 3f;
        }else {
            SPEED = 2f;
        }
    
        if (Gdx.input.isKeyPressed(Input.Keys.W)) {
            newY += SPEED;
            direction = 3;
            isMoving = true;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.S)) {
            newY -= SPEED;
            direction = 0;
            isMoving = true;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            newX -= SPEED;
            direction = 1;
            isMoving = true;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            newX += SPEED;
            direction = 2;
            isMoving = true;
        }
    
        // Check X-axis collision
        if (isTileWalkable(newX, y)) {
            x = newX;
        }
    
        // Check Y-axis collision
        if (isTileWalkable(x, newY)) {
            y = newY;
        }

        // Check for combat initiation
        if (isTileCombatEncounter(newX, newY)) {
            // Trigger combat

        }
    
        if (isMoving) {
            stateTime += delta;
        } else {
            stateTime = 0;
        }
    }

    private boolean isTileCombatEncounter(float x, float y) {
        // Placeholder logic to trigger combat based on specific coordinates
        // For example, trigger combat if the player steps on tile (10, 10)
        int tileX = (int) (x / collisionLayer.getTileWidth());
        int tileY = (int) (y / collisionLayer.getTileHeight());

        return tileX == 10 && tileY == 10; // Change these coordinates as needed
    }

    public void render(SpriteBatch batch) {
        TextureRegion currentFrame;
        if (isMoving) {
            currentFrame = walkAnimations[direction].getKeyFrame(stateTime);
        } else {
            currentFrame = idleFrame;
        }
        batch.draw(
            currentFrame,
            x,
            y,
            40, // Width scaled
            40 // Height scaled
        );
    }

    public void dispose() {
        texture.dispose();
    }
    
    public Vector2 getPosition() {
        return new Vector2(x, y);
    }

    public float getX() {
        return x;
    }
    
    public float getY() {
        return y;
    }

    public int attack() {
        return random.nextInt(damage + 1);
    }

    public void takeDamage(int damage) {
        this.troops -= damage;
        if (this.troops < 0) {
            this.troops = 0;
        }
    }

    public boolean isAlive() {
        return troops > 0;
    }

    public int getTroops() {
        return troops;
    }

    public String getName() {
        return "Player"; // Placeholder name
    }

    public GameLauncher getGame() {
        return game;
    }

    public void setGame(GameLauncher game) {
        this.game = game;
    }

    public int getMaxTroops() {
        return maxTroops;
    }

    public int getDamage() {
        return damage;
    }
}
