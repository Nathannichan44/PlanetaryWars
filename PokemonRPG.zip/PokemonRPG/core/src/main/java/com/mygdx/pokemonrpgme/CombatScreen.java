package com.mygdx.pokemonrpgme;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;

public class CombatScreen implements Screen {
    private final GameLauncher game;
    private final Player player;
    private final Enemy enemy;

    private OrthographicCamera camera;
    private Viewport viewport;
    private Stage stage;
    private SpriteBatch batch;

    private Texture backgroundTexture;

    private Label playerInfoLabel;
    private Label enemyInfoLabel;
    private Label timelineLabel;

    private Animation<TextureRegion> playerIdleAnimation;
    private Animation<TextureRegion> playerAttackAnimation;
    private Animation<TextureRegion> playerDamageAnimation;
    private Animation<TextureRegion> playerDeathAnimation;
    private Animation<TextureRegion> enemyIdleAnimation;
    private Animation<TextureRegion> enemyAttackAnimation;

    private Texture playerSpritesheet;
    private Texture enemySpritesheet;
    private Texture playerAttackSpriteSheet;
    private Texture playerDamageSpriteSheet;
    private Texture playerDeathSpriteSheet;
    private Texture enemyAttackSpriteSheet;

    private float playerStateTime;
    private float enemyStateTime;
    private float sideKickStateTime;
    private float playerDamageStateTime;
    private float playerDeathStateTime;
    private boolean isPlayerAttacking;
    private boolean isPlayerTakingDamage;
    private boolean isPlayerDying;
    private boolean isSideKick1Attacking;
    private boolean isSideKick2Attacking;
    private boolean isEnemyAttacking;
    private boolean playerTurn;
    private boolean combatOngoing;

    private ScrollPane timelineScrollPane;

    public CombatScreen(GameLauncher game, Player player, Enemy enemy) {
        this.game = game;
        this.player = player;
        this.enemy = enemy;

        initialize();
        playerTurn = true; 
        combatOngoing = true; 
    }

    private void initialize() {
        camera = new OrthographicCamera();
        viewport = new FitViewport(915, 610, camera);
        batch = new SpriteBatch();
        stage = new Stage(viewport, batch);
        sideKickStateTime = 0;

        backgroundTexture = new Texture(Gdx.files.internal("test.jpg"));

        
        playerSpritesheet = new Texture(Gdx.files.internal("player_idle.png")); 
        enemySpritesheet = new Texture(Gdx.files.internal("enemy.png")); 
        playerAttackSpriteSheet = new Texture(Gdx.files.internal("player_attack.png")); 
        playerDamageSpriteSheet = new Texture(Gdx.files.internal("player_damage.png")); 
        playerDeathSpriteSheet = new Texture(Gdx.files.internal("player_death.png")); 
        enemyAttackSpriteSheet = new Texture(Gdx.files.internal("enemy.png")); 

        playerIdleAnimation = createAnimation(playerSpritesheet, 64, 64, 12, 0.2f); 
        playerAttackAnimation = createAnimation(playerAttackSpriteSheet, 64, 64, 8, 0.1f); 
        playerDamageAnimation = createAnimation(playerDamageSpriteSheet, 64, 64, 5, 0.15f); 
        playerDeathAnimation = createAnimation(playerDeathSpriteSheet, 64, 64, 7, 0.2f); 
        enemyIdleAnimation = createAnimation(enemySpritesheet, 64, 64, 5, 0.2f); 
        enemyAttackAnimation = createAnimation(enemyAttackSpriteSheet, 64, 64, 5, 0.1f); 

        initializeUI();
    }

    private void initializeUI() {
        Skin skin = new Skin(Gdx.files.internal("uiskin.json"));

        Table rootTable = new Table();
        rootTable.setFillParent(true);
        stage.addActor(rootTable);

        
        Table playerTable = new Table();
        playerInfoLabel = new Label("You:\nHP: " + player.getHealth(), skin);
        playerTable.add(playerInfoLabel).pad(130).padLeft(300).row();
        rootTable.add(playerTable).width(200).pad(10).top();

        
        BitmapFont font = new BitmapFont();
        Label.LabelStyle smallStyle = new Label.LabelStyle(font, Color.WHITE);
        timelineLabel = new Label("Fight Timeline:\n", smallStyle);
        timelineLabel.setWrap(true);

        timelineScrollPane = new ScrollPane(timelineLabel, skin);
        timelineScrollPane.setFadeScrollBars(false);
        timelineScrollPane.setScrollingDisabled(true, false);
        rootTable.add(timelineScrollPane).expand().fillX().height(100).pad(10).bottom();

        
        Table enemyTable = new Table();
        enemyInfoLabel = new Label("Enemy: " + enemy.getName() + "\nHP: " + enemy.getHealth(), skin);
        enemyTable.add(enemyInfoLabel).pad(5).row();
        rootTable.add(enemyTable).width(200).pad(80).top();

        rootTable.row();

        
        Table actionTable = new Table(skin);
        ScrollPane actionScrollPane = new ScrollPane(actionTable, skin);
        actionScrollPane.setScrollingDisabled(true, false);
        actionScrollPane.setFadeScrollBars(false);
        rootTable.add(actionScrollPane).colspan(3).expandX().fillX().pad(10);

        createActionButtons(actionTable, skin, timelineScrollPane);
    }

    private void createActionButtons(Table actionTable, Skin skin, ScrollPane timelineScrollPane) {
        TextButton attackButton = new TextButton("1: Launch Assault", skin);
        attackButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (player.isAlive() && enemy.isAlive() && playerTurn && combatOngoing) {
                    handlePlayerAttack();
                }
            }
        });
        actionTable.add(attackButton).expandX().fillX().pad(5);
        actionTable.row();

        TextButton defendButton = new TextButton("2: Defend", skin);
        defendButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (player.isAlive() && enemy.isAlive() && playerTurn && combatOngoing) {
                    player.defend();
                    timelineLabel.setText(timelineLabel.getText() + "\nYou defend.");
                    updateLabels();

                    
                    Gdx.app.postRunnable(() -> {
                        timelineScrollPane.setScrollY(timelineScrollPane.getMaxY());
                        timelineScrollPane.updateVisualScroll();
                    });

                    
                    new Thread(() -> {
                        try {
                            Thread.sleep(1000);
                            Gdx.app.postRunnable(() -> {
                                if (combatOngoing) handleSideKick1Attack();
                            });
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }).start();

                    
                    new Thread(() -> {
                        try {
                            Thread.sleep(2000);
                            Gdx.app.postRunnable(() -> {
                                if (combatOngoing) handleSideKick2Attack();
                            });
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }).start();

                    
                    new Thread(() -> {
                        try {
                            Thread.sleep(3000);
                            Gdx.app.postRunnable(() -> {
                                if (combatOngoing) handleEnemyTurn();
                            });
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }).start();
                }
            }
        });
        actionTable.add(defendButton).expandX().fillX().pad(5);
        actionTable.row();

        TextButton retreatButton = new TextButton("3: Retreat", skin);
        retreatButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new GameScreen(game));
            }
        });
        actionTable.add(retreatButton).expandX().fillX().pad(5);
    }

    private void handlePlayerAttack() {
        playerStateTime = 0f; 
        isPlayerAttacking = true; 

        int damage = player.attack();
        enemy.takeDamage(damage);

        timelineLabel.setText(timelineLabel.getText() + "\nYou deal " + damage + " damage to the enemy.");
        updateLabels();

        if (!enemy.isAlive()) {
            timelineLabel.setText(timelineLabel.getText() + "\nEnemy defeated!");
            showPrompt("Victory", "You defeated the enemy! Exit combat?", true);
            combatOngoing = false;
        } else {

            new Thread(() -> {
                try {
                    Thread.sleep(1000);
                    Gdx.app.postRunnable(() -> {
                        if (combatOngoing) handleSideKick1Attack();
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();

            new Thread(() -> {
                try {
                    Thread.sleep(2000);
                    Gdx.app.postRunnable(() -> {
                        if (combatOngoing) handleSideKick2Attack();
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();

            new Thread(() -> {
                try {
                    Thread.sleep(3000);
                    Gdx.app.postRunnable(() -> {
                        if (combatOngoing) handleEnemyTurn();
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }

    private void handleSideKick1Attack() {
        sideKickStateTime = 0f; 
        isSideKick1Attacking = true; 

        int damage = player.attack();
        enemy.takeDamage(damage);

        timelineLabel.setText(timelineLabel.getText() + "\nSidekick 1 deals " + damage + " damage to the enemy.");
        updateLabels();

        if (!enemy.isAlive()) {
            timelineLabel.setText(timelineLabel.getText() + "\nEnemy defeated!");
            showPrompt("Victory", "You defeated the enemy! Exit combat?", true);
            combatOngoing = false;
        }
    }

    private void handleSideKick2Attack() {
        sideKickStateTime = 0f; 
        isSideKick2Attacking = true; 

        
        int damage = player.attack(); 
        enemy.takeDamage(damage);

        timelineLabel.setText(timelineLabel.getText() + "\nSidekick 2 deals " + damage + " damage to the enemy.");
        updateLabels();

        if (!enemy.isAlive()) {
            timelineLabel.setText(timelineLabel.getText() + "\nEnemy defeated!");
            showPrompt("Victory", "You defeated the enemy! Exit combat?", true);
            combatOngoing = false;
        }
    }

    private void handleEnemyTurn() {
        enemyStateTime = 0f;
        isEnemyAttacking = true; 

        int damage = enemy.makeAttack();
        player.takeDamage(damage);

        timelineLabel.setText(timelineLabel.getText() + "\nEnemy deals " + damage + " damage to you.");
        updateLabels();

        if (!player.isAlive()) {
            timelineLabel.setText(timelineLabel.getText() + "\nYou have been defeated!");
            showPrompt("Defeat", "You have been defeated! Exit combat?", false);
            combatOngoing = false;
            playerDeathStateTime = 0f;
            isPlayerDying = true;
        } else {
            playerTurn = true;
        }

        playerDamageStateTime = 0f;
        isPlayerTakingDamage = true;
    }

    private void showPrompt(String title, String message, boolean won) {
        Skin skin = new Skin(Gdx.files.internal("uiskin.json"));
        Dialog dialog = new Dialog(title, skin) {
            @Override
            protected void result(Object object) {
                if ((Boolean) object) {
                    game.setScreen(new GameScreen(game));
                } else if(!won){
                    game.setScreen(new MainMenuScreen(game));
                }
            }
        };
        dialog.text(message);
        if(won){
        dialog.button("Exit", true);
        dialog.button("Stay", false);}
        else{
            dialog.button("Return to main menu", false);
        }
        dialog.show(stage);
    }

    private void updateLabels() {
        playerInfoLabel.setText("You:\nHP: " + player.getHealth());
        enemyInfoLabel.setText("Enemy: " + enemy.getName() + "\nHP: " + enemy.getHealth());
        timelineLabel.setText(timelineLabel.getText() + "\n");

        Gdx.app.postRunnable(() -> {
            timelineScrollPane.setScrollY(timelineScrollPane.getMaxY());
            timelineScrollPane.updateVisualScroll();
        });
    }

    private Animation<TextureRegion> createAnimation(Texture spritesheet, int frameWidth, int frameHeight, int frameCount, float frameDuration) {
        TextureRegion[][] tmp = TextureRegion.split(spritesheet, frameWidth, frameHeight);
        TextureRegion[] frames = new TextureRegion[frameCount];
        System.arraycopy(tmp[0], 0, frames, 0, frameCount);
        return new Animation<>(frameDuration, frames);
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
public void render(float delta) {
    playerStateTime += delta;
    enemyStateTime += delta;
    sideKickStateTime += delta;
    playerDamageStateTime += delta;
    playerDeathStateTime += delta;

    Gdx.gl.glClearColor(0, 0, 0, 1);
    Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

    batch.begin();
    batch.draw(backgroundTexture, 0, 0, viewport.getWorldWidth(), viewport.getWorldHeight());

    TextureRegion playerFrame;
    if (isPlayerDying) {
        playerFrame = playerDeathAnimation.getKeyFrame(playerDeathStateTime, false);
    } else if (isPlayerAttacking && !playerAttackAnimation.isAnimationFinished(playerStateTime)) {
        playerFrame = playerAttackAnimation.getKeyFrame(playerStateTime, false);
    } else if (isPlayerTakingDamage && !playerDamageAnimation.isAnimationFinished(playerDamageStateTime)) {
        playerFrame = playerDamageAnimation.getKeyFrame(playerDamageStateTime, false);
    } else {
        playerFrame = playerIdleAnimation.getKeyFrame(playerStateTime, true);
    }
    batch.draw(playerFrame, 60, 250, 256, 256);

    TextureRegion sideKick1Frame = isSideKick1Attacking
            ? playerAttackAnimation.getKeyFrame(sideKickStateTime, false)
            : playerIdleAnimation.getKeyFrame(sideKickStateTime, true);
    batch.draw(sideKick1Frame, -20, 380, 256, 256);

    TextureRegion sideKick2Frame = isSideKick2Attacking
            ? playerAttackAnimation.getKeyFrame(sideKickStateTime, false)
            : playerIdleAnimation.getKeyFrame(sideKickStateTime, true);
    batch.draw(sideKick2Frame, -20, 120, 256, 256);

    TextureRegion enemyFrame = isEnemyAttacking && !enemyAttackAnimation.isAnimationFinished(enemyStateTime)
            ? enemyAttackAnimation.getKeyFrame(enemyStateTime, false)
            : enemyIdleAnimation.getKeyFrame(enemyStateTime, true);
    batch.draw(enemyFrame, 600, 230, 256, 256);

    if (isPlayerAttacking && playerAttackAnimation.isAnimationFinished(playerStateTime)) {
        isPlayerAttacking = false;
    }

    if (isSideKick1Attacking && playerAttackAnimation.isAnimationFinished(sideKickStateTime)) {
        isSideKick1Attacking = false;
    }

    if (isSideKick2Attacking && playerAttackAnimation.isAnimationFinished(sideKickStateTime)) {
        isSideKick2Attacking = false;
    }

    if (isEnemyAttacking && enemyAttackAnimation.isAnimationFinished(enemyStateTime)) {
        isEnemyAttacking = false;
    }

    if (isPlayerTakingDamage && playerDamageAnimation.isAnimationFinished(playerDamageStateTime)) {
        isPlayerTakingDamage = false;
    }

    batch.end();
    stage.act(delta);
    stage.draw();
}


    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        batch.dispose();
        backgroundTexture.dispose();
        playerSpritesheet.dispose();
        playerAttackSpriteSheet.dispose();
        playerDamageSpriteSheet.dispose();
        playerDeathSpriteSheet.dispose();
        enemySpritesheet.dispose();
        enemyAttackSpriteSheet.dispose();
        stage.dispose();
    }
}
