package com.mygdx.pokemonrpgme;

public class Item {
    public enum EffectType {
        HEALTH_BOOST,
        DAMAGE_OVER_TIME,
        GOLD_BOOST
    }

    private String name;
    private int cost;
    private EffectType effectType;
    private int effectValue;
    private boolean owned;

    public Item(String name, int cost, EffectType effectType, int effectValue) {
        this.name = name;
        this.cost = cost;
        this.effectType = effectType;
        this.effectValue = effectValue;
        this.owned = false;
    }

    public String getName() {
        return name;
    }

    public int getCost() {
        return cost;
    }

    public EffectType getEffectType() {
        return effectType;
    }

    public int getEffectValue() {
        return effectValue;
    }

    public boolean isOwned() {
        return owned;
    }

    public void setOwned(boolean owned) {
        this.owned = owned;
    }
}
