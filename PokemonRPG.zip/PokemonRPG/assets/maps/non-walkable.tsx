<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="non-walkable" tilewidth="16" tileheight="16" tilecount="2500" columns="50">
 <image source="nonwalkable.png" width="805" height="805"/>
 <tile id="0">
  <properties>
   <property name="walkable" type="bool" value="false"/>
  </properties>
 </tile>
</tileset>
