package com.mygdx.pokemonrpgme;

import com.badlogic.gdx.Game;

public class GameLauncher extends Game {
    @Override
    public void create() {
        setScreen(new MainMenuScreen(this)); // Start with the main menu screen
    }

    public GameScreen getGameScreen() {
        if (getScreen() instanceof GameScreen) {
            return (GameScreen) getScreen();
        }                                                      
        return null;
    }
}
