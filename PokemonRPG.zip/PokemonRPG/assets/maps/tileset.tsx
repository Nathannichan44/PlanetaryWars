<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tileset" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <grid orientation="orthogonal" width="48" height="48"/>
 <image source="tiles.png" width="16" height="16"/>
 <tile id="0">
  <properties>
   <property name="walkable" type="bool" value="true"/>
  </properties>
  <objectgroup draworder="index" id="4">
   <object id="5" x="-0.0909091" y="0" width="16.1818" height="15.9091">
    <properties>
     <property name="Collision" type="bool" value="true"/>
     <property name="collidable" type="bool" value="true"/>
    </properties>
   </object>
  </objectgroup>
 </tile>
</tileset>
