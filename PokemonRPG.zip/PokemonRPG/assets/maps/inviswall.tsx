<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="inviswall" tilewidth="48" tileheight="48" tilecount="1" columns="1">
 <image source="../inviswall.png" width="48" height="48"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="5" x="0" y="0" width="48" height="48"/>
   <object id="7" x="1" y="0" width="49" height="47">
    <properties>
     <property name="collision" type="bool" value="true"/>
    </properties>
   </object>
   <object id="8" x="5" y="39" width="2" height="2"/>
  </objectgroup>
 </tile>
</tileset>
